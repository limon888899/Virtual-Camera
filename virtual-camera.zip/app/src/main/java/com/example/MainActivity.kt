package com.example

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Equalizer
import androidx.compose.material.icons.filled.Face
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.ui.screens.Android15SecurityScreen
import com.example.ui.screens.LipSyncStudioScreen
import com.example.ui.screens.PlaylistScreen
import com.example.ui.screens.VirtualSpaceScreen
import androidx.compose.material.icons.filled.SpaceDashboard

import com.example.ui.screens.VirtualCamStudioScreen
import com.example.ui.screens.VoiceAudioScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.viewmodel.VirtualCamViewModel
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    private val viewModel: VirtualCamViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            MyApplicationTheme(darkTheme = true) {
                MainAppScreen(viewModel = viewModel)
            }
        }
    }
}

@Composable
fun MainAppScreen(viewModel: VirtualCamViewModel) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }

    var currentTab by remember { mutableIntStateOf(0) }

    val videos by viewModel.videos.collectAsState()
    val settings by viewModel.settings.collectAsState()
    val isServiceActive by viewModel.isServiceBound.collectAsState()
    val currentIndex by viewModel.currentVideoIndex.collectAsState()
    val isPlaying by viewModel.isPlaying.collectAsState()
    val lipSyncState by viewModel.lipSyncState.collectAsState()
    val audioEnergy by viewModel.audioEnergy.collectAsState()
    val audioDecibels by viewModel.audioDecibels.collectAsState()
    
    val installedApps by viewModel.installedApps.collectAsState()
    val clonedApps by viewModel.clonedApps.collectAsState()

    val currentVideo = videos.getOrNull(currentIndex)

    // MediaProjection launcher for Android 14/15
    val mediaProjectionManager = remember {
        context.getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
    }

    val mediaProjectionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK && result.data != null) {
            viewModel.startService(result.resultCode, result.data)
            coroutineScope.launch {
                snackbarHostState.showSnackbar("Virtual Camera Service started with MediaProjection!")
            }
        } else {
            // Fallback start without projection token
            viewModel.startService()
            coroutineScope.launch {
                snackbarHostState.showSnackbar("Virtual Camera started in Overlay Mode.")
            }
        }
    }

    // Permission launcher for Mic & Camera & Notifications
    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val micGranted = permissions[Manifest.permission.RECORD_AUDIO] == true
        if (micGranted) {
            coroutineScope.launch {
                snackbarHostState.showSnackbar("Microphone permission granted for AI Lip-Sync & Audio FX.")
            }
        }
    }

    // Request necessary permissions on initial launch
    LaunchedEffect(Unit) {
        val permsToRequest = mutableListOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.CAMERA)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            permsToRequest.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        val missing = permsToRequest.filter {
            ContextCompat.checkSelfPermission(context, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isNotEmpty()) {
            permissionLauncher.launch(missing.toTypedArray())
        }
    }

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .testTag("virtual_cam_main_scaffold"),
        snackbarHost = { SnackbarHost(snackbarHostState) },
        bottomBar = {
            NavigationBar(
                containerColor = Color(0xFF0F141C),
                contentColor = Color.White
            ) {
                // Studio Tab
                NavigationBarItem(
                    selected = currentTab == 0,
                    onClick = { currentTab = 0 },
                    icon = { Icon(Icons.Default.Videocam, contentDescription = "Studio") },
                    label = { Text("Studio", fontSize = 11.sp, fontWeight = FontWeight.SemiBold) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color.Black,
                        selectedTextColor = Color(0xFF00CEC9),
                        indicatorColor = Color(0xFF00CEC9),
                        unselectedIconColor = Color.White.copy(alpha = 0.6f),
                        unselectedTextColor = Color.White.copy(alpha = 0.6f)
                    ),
                    modifier = Modifier.testTag("tab_studio")
                )

                // Playlist Tab
                NavigationBarItem(
                    selected = currentTab == 1,
                    onClick = { currentTab = 1 },
                    icon = { Icon(Icons.Default.VideoLibrary, contentDescription = "Playlist") },
                    label = { Text("Playlist", fontSize = 11.sp, fontWeight = FontWeight.SemiBold) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color.Black,
                        selectedTextColor = Color(0xFF6C5CE7),
                        indicatorColor = Color(0xFF6C5CE7),
                        unselectedIconColor = Color.White.copy(alpha = 0.6f),
                        unselectedTextColor = Color.White.copy(alpha = 0.6f)
                    ),
                    modifier = Modifier.testTag("tab_playlist")
                )

                // Lip-Sync Tab
                NavigationBarItem(
                    selected = currentTab == 2,
                    onClick = { currentTab = 2 },
                    icon = { Icon(Icons.Default.Face, contentDescription = "Lip-Sync") },
                    label = { Text("Lip-Sync", fontSize = 11.sp, fontWeight = FontWeight.SemiBold) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color.Black,
                        selectedTextColor = Color(0xFFE84393),
                        indicatorColor = Color(0xFFE84393),
                        unselectedIconColor = Color.White.copy(alpha = 0.6f),
                        unselectedTextColor = Color.White.copy(alpha = 0.6f)
                    ),
                    modifier = Modifier.testTag("tab_lip_sync")
                )

                // Voice FX Tab
                NavigationBarItem(
                    selected = currentTab == 3,
                    onClick = { currentTab = 3 },
                    icon = { Icon(Icons.Default.Equalizer, contentDescription = "Voice FX") },
                    label = { Text("Voice FX", fontSize = 11.sp, fontWeight = FontWeight.SemiBold) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color.Black,
                        selectedTextColor = Color(0xFF00E676),
                        indicatorColor = Color(0xFF00E676),
                        unselectedIconColor = Color.White.copy(alpha = 0.6f),
                        unselectedTextColor = Color.White.copy(alpha = 0.6f)
                    ),
                    modifier = Modifier.testTag("tab_voice_fx")
                )

                // Android 15 & Security Tab
                NavigationBarItem(
                    selected = currentTab == 4,
                    onClick = { currentTab = 4 },
                    icon = { Icon(Icons.Default.Security, contentDescription = "OS 15") },
                    label = { Text("OS 15", fontSize = 11.sp, fontWeight = FontWeight.SemiBold) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color.Black,
                        selectedTextColor = Color(0xFF74B9FF),
                        indicatorColor = Color(0xFF74B9FF),
                        unselectedIconColor = Color.White.copy(alpha = 0.6f),
                        unselectedTextColor = Color.White.copy(alpha = 0.6f)
                    ),
                    modifier = Modifier.testTag("tab_android15")
                )

                // Virtual Space Tab
                NavigationBarItem(
                    selected = currentTab == 5,
                    onClick = { currentTab = 5 },
                    icon = { Icon(Icons.Default.SpaceDashboard, contentDescription = "Virtual Space") },
                    label = { Text("App Cloner", fontSize = 11.sp, fontWeight = FontWeight.SemiBold) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color.Black,
                        selectedTextColor = Color(0xFFE1B12C),
                        indicatorColor = Color(0xFFE1B12C),
                        unselectedIconColor = Color.White.copy(alpha = 0.6f),
                        unselectedTextColor = Color.White.copy(alpha = 0.6f)
                    ),
                    modifier = Modifier.testTag("tab_virtual_space")
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFF0B0E14))
                .padding(innerPadding)
        ) {
            when (currentTab) {
                0 -> VirtualCamStudioScreen(
                    currentVideo = currentVideo,
                    settings = settings,
                    isPlaying = isPlaying,
                    isServiceActive = isServiceActive,
                    lipSyncState = lipSyncState,
                    audioEnergy = audioEnergy,
                    audioDecibels = audioDecibels,
                    onStartService = {
                        // Check overlay permission first for floating bubble
                        if (!Settings.canDrawOverlays(context)) {
                            coroutineScope.launch {
                                snackbarHostState.showSnackbar("Please grant 'Display over other apps' to enable floating overlay.")
                            }
                            val intent = Intent(
                                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                Uri.parse("package:${context.packageName}")
                            )
                            context.startActivity(intent)
                        }

                        // Launch media projection consent
                        try {
                            mediaProjectionLauncher.launch(mediaProjectionManager.createScreenCaptureIntent())
                        } catch (e: Exception) {
                            viewModel.startService()
                        }
                    },
                    onStopService = {
                        viewModel.stopService()
                        coroutineScope.launch {
                            snackbarHostState.showSnackbar("Virtual Camera Service stopped.")
                        }
                    },
                    onToggleCam = { viewModel.toggleVirtualCam() },
                    onTogglePlayPause = { viewModel.togglePlayPause() },
                    onToggleMirror = { viewModel.toggleMirror() },
                    onNextVideo = { viewModel.nextVideo() },
                    onPrevVideo = { viewModel.prevVideo() },
                    onToggleLipSync = { viewModel.updateLipSync(it) },
                    onToggleNoiseCancellation = { viewModel.updateNoiseCancellation(it) }
                )

                1 -> PlaylistScreen(
                    videos = videos,
                    currentIndex = currentIndex,
                    settings = settings,
                    onSelectVideo = { viewModel.selectVideo(it) },
                    onDeleteVideo = { viewModel.deleteVideo(it) },
                    onImportVideos = { viewModel.importVideos(it) },
                    onUpdateLoopMode = { viewModel.updateLoopMode(it) },
                    onUpdateSpeed = { viewModel.updateSpeed(it) }
                )

                2 -> LipSyncStudioScreen(
                    lipSyncState = lipSyncState,
                    sensitivity = settings.lipSyncSensitivity,
                    isEnabled = settings.lipSyncEnabled,
                    onToggleEnabled = { viewModel.updateLipSync(it) },
                    onUpdateSensitivity = { viewModel.updateLipSyncSensitivity(it) }
                )

                3 -> VoiceAudioScreen(
                    energy = audioEnergy,
                    decibels = audioDecibels,
                    isAudioActive = isServiceActive,
                    isNoiseCancellationEnabled = settings.noiseCancellationEnabled,
                    currentVoicePreset = com.example.data.model.VoicePreset.fromString(settings.voicePreset),
                    onToggleNoiseCancellation = { viewModel.updateNoiseCancellation(it) },
                    onSelectVoicePreset = { viewModel.selectVoicePreset(it) }
                )

                4 -> Android15SecurityScreen()

                5 -> VirtualSpaceScreen(
                    installedApps = installedApps,
                    clonedApps = clonedApps,
                    onCloneApp = { viewModel.cloneApp(it) },
                    onRemoveClonedApp = { viewModel.removeClonedApp(it) },
                    onLaunchClonedApp = { viewModel.launchClonedApp(it) }
                )
            }
        }
    }
}
