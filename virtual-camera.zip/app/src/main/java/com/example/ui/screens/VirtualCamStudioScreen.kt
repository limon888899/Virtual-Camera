package com.example.ui.screens

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Face
import androidx.compose.material.icons.filled.Flip
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PictureInPicture
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material.icons.filled.VideocamOff
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.entity.AppSettingsEntity
import com.example.data.local.entity.VideoEntity
import com.example.data.model.LipSyncState
import com.example.service.VirtualCameraService
import com.example.ui.components.AudioWaveformVisualizer
import com.example.ui.components.VirtualCamFeedView

@Composable
fun VirtualCamStudioScreen(
    currentVideo: VideoEntity?,
    settings: AppSettingsEntity,
    isPlaying: Boolean,
    isServiceActive: Boolean,
    lipSyncState: LipSyncState,
    audioEnergy: Float,
    audioDecibels: Float,
    onStartService: () -> Unit,
    onStopService: () -> Unit,
    onToggleCam: () -> Unit,
    onTogglePlayPause: () -> Unit,
    onToggleMirror: () -> Unit,
    onNextVideo: () -> Unit,
    onPrevVideo: () -> Unit,
    onToggleLipSync: (Boolean) -> Unit,
    onToggleNoiseCancellation: (Boolean) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val hasOverlayPermission = Settings.canDrawOverlays(context)
    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Top Live Virtual Camera Feed Window
        VirtualCamFeedView(
            video = currentVideo,
            isPlaying = isPlaying,
            isMirrored = settings.isMirrorHorizontal,
            isVirtualCamActive = settings.isVirtualCamActive && isServiceActive,
            lipSyncState = lipSyncState,
            onTogglePlayPause = onTogglePlayPause,
            onToggleMirror = onToggleMirror,
            modifier = Modifier
                .fillMaxWidth()
                .height(290.dp)
        )

        Spacer(modifier = Modifier.height(14.dp))

        // Playback Controller Card
        Card(
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF161B22)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Virtual Camera Engine",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Text(
                            text = if (isServiceActive) "Active in Background (Android 15 FGS)" else "Service Stopped",
                            fontSize = 11.sp,
                            color = if (isServiceActive) Color(0xFF00E676) else Color.White.copy(alpha = 0.6f)
                        )
                    }

                    // Master Start/Stop Service Button
                    FilledTonalButton(
                        onClick = {
                            if (isServiceActive) onStopService() else onStartService()
                        },
                        colors = ButtonDefaults.filledTonalButtonColors(
                            containerColor = if (isServiceActive) Color(0xFFFF5252) else Color(0xFF00B894)
                        ),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.PowerSettingsNew,
                            contentDescription = "Power",
                            tint = Color.White,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (isServiceActive) "STOP" else "START",
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Control action buttons row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Prev
                    IconButton(
                        onClick = onPrevVideo,
                        colors = IconButtonDefaults.iconButtonColors(containerColor = Color(0xFF22272E)),
                        modifier = Modifier.size(44.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.SkipPrevious,
                            contentDescription = "Previous Video",
                            tint = Color.White
                        )
                    }

                    // Play/Pause Main
                    IconButton(
                        onClick = onTogglePlayPause,
                        colors = IconButtonDefaults.iconButtonColors(
                            containerColor = Color(0xFF6C5CE7)
                        ),
                        modifier = Modifier.size(52.dp)
                    ) {
                        Icon(
                            imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                            contentDescription = "Play/Pause",
                            tint = Color.White,
                            modifier = Modifier.size(28.dp)
                        )
                    }

                    // Next
                    IconButton(
                        onClick = onNextVideo,
                        colors = IconButtonDefaults.iconButtonColors(containerColor = Color(0xFF22272E)),
                        modifier = Modifier.size(44.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.SkipNext,
                            contentDescription = "Next Video",
                            tint = Color.White
                        )
                    }

                    // Mirror Toggle
                    IconButton(
                        onClick = onToggleMirror,
                        colors = IconButtonDefaults.iconButtonColors(
                            containerColor = if (settings.isMirrorHorizontal) Color(0xFFE84393) else Color(0xFF22272E)
                        ),
                        modifier = Modifier.size(44.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Flip,
                            contentDescription = "Mirror Flip",
                            tint = Color.White
                        )
                    }

                    // Feed Active Switch
                    IconButton(
                        onClick = onToggleCam,
                        colors = IconButtonDefaults.iconButtonColors(
                            containerColor = if (settings.isVirtualCamActive) Color(0xFF00CEC9) else Color(0xFF22272E)
                        ),
                        modifier = Modifier.size(44.dp)
                    ) {
                        Icon(
                            imageVector = if (settings.isVirtualCamActive) Icons.Default.Videocam else Icons.Default.VideocamOff,
                            contentDescription = "Virtual Cam Stream",
                            tint = Color.White
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Floating Control Panel / Bubble Card (WhatsApp / Zoom Assistant)
        Card(
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF161B22)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(38.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(Color(0xFF0984E3)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.PictureInPicture,
                                contentDescription = "Floating Overlay",
                                tint = Color.White,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "Floating Control Bubble",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                            Text(
                                text = "Over WhatsApp, IMO, Facebook Live, Zoom",
                                fontSize = 11.sp,
                                color = Color.White.copy(alpha = 0.65f)
                            )
                        }
                    }

                    if (!hasOverlayPermission) {
                        OutlinedButton(
                            onClick = {
                                val intent = Intent(
                                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                    Uri.parse("package:${context.packageName}")
                                )
                                context.startActivity(intent)
                            },
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text("Grant", fontSize = 12.sp)
                        }
                    } else {
                        Button(
                            onClick = {
                                val intent = Intent(context, VirtualCameraService::class.java).apply {
                                    action = VirtualCameraService.ACTION_SHOW_OVERLAY
                                }
                                context.startService(intent)
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0984E3)),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text("Launch Bubble", fontSize = 12.sp)
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Live Audio & AI Lip-Sync Waveform Card
        Card(
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF161B22)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Mic,
                            contentDescription = "Audio Waveform",
                            tint = Color(0xFF00CEC9),
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Live Audio & Phoneme Analysis",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }

                    Text(
                        text = "${audioDecibels.toInt()} dB • Phoneme [${lipSyncState.currentPhoneme}]",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = Color(0xFF00CEC9)
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                AudioWaveformVisualizer(
                    energy = audioEnergy,
                    decibels = audioDecibels,
                    activeColor = Color(0xFF00CEC9),
                    accentColor = Color(0xFF6C5CE7)
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Quick AI Lip-Sync & Noise Shield Toggles
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Face,
                            contentDescription = "Lip-Sync",
                            tint = Color(0xFF74B9FF),
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "AI Lip-Sync Engine",
                            fontSize = 12.sp,
                            color = Color.White
                        )
                    }
                    Switch(
                        checked = settings.lipSyncEnabled,
                        onCheckedChange = onToggleLipSync,
                        colors = SwitchDefaults.colors(checkedThumbColor = Color(0xFF00CEC9))
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Security,
                            contentDescription = "Noise Shield",
                            tint = Color(0xFF00E676),
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Noise Cancellation Shield",
                            fontSize = 12.sp,
                            color = Color.White
                        )
                    }
                    Switch(
                        checked = settings.noiseCancellationEnabled,
                        onCheckedChange = onToggleNoiseCancellation,
                        colors = SwitchDefaults.colors(checkedThumbColor = Color(0xFF00E676))
                    )
                }
            }
        }
    }
}
