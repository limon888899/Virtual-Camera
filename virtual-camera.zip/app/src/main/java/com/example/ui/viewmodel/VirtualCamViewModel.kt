package com.example.ui.viewmodel

import android.app.Application
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.net.Uri
import android.os.Build
import android.os.IBinder
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.entity.AppSettingsEntity
import com.example.data.local.entity.VideoEntity
import com.example.data.model.LipSyncState
import com.example.data.model.VoicePreset
import com.example.data.repository.VirtualCamRepository
import com.example.service.VirtualCameraService
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

import android.content.pm.PackageManager
import com.example.data.model.AppInfo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class VirtualCamViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = VirtualCamRepository(application)

    val videos: StateFlow<List<VideoEntity>> = repository.allVideos
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val settings: StateFlow<AppSettingsEntity> = repository.settingsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), AppSettingsEntity())

    // Virtual Space App Management
    private val _installedApps = MutableStateFlow<List<AppInfo>>(emptyList())
    val installedApps: StateFlow<List<AppInfo>> = _installedApps.asStateFlow()

    private val _clonedApps = MutableStateFlow<List<AppInfo>>(emptyList())
    val clonedApps: StateFlow<List<AppInfo>> = _clonedApps.asStateFlow()

    private val _isServiceBound = MutableStateFlow(false)
    val isServiceBound: StateFlow<Boolean> = _isServiceBound.asStateFlow()

    private val _currentVideoIndex = MutableStateFlow(0)
    val currentVideoIndex: StateFlow<Int> = _currentVideoIndex.asStateFlow()

    private val _isPlaying = MutableStateFlow(true)
    val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()

    private val _lipSyncState = MutableStateFlow(LipSyncState())
    val lipSyncState: StateFlow<LipSyncState> = _lipSyncState.asStateFlow()

    private val _audioEnergy = MutableStateFlow(0f)
    val audioEnergy: StateFlow<Float> = _audioEnergy.asStateFlow()

    private val _audioDecibels = MutableStateFlow(-60f)
    val audioDecibels: StateFlow<Float> = _audioDecibels.asStateFlow()

    private var virtualCameraService: VirtualCameraService? = null

    private val serviceConnection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
            val localBinder = binder as? VirtualCameraService.LocalBinder
            val service = localBinder?.getService()
            virtualCameraService = service
            _isServiceBound.value = true

            // Observe service flows
            service?.let { s ->
                viewModelScope.launch {
                    s.isPlaying.collect { _isPlaying.value = it }
                }
                viewModelScope.launch {
                    s.currentVideoIndex.collect { _currentVideoIndex.value = it }
                }
                viewModelScope.launch {
                    s.lipSyncEngine.lipSyncState.collect { _lipSyncState.value = it }
                }
                viewModelScope.launch {
                    s.audioEngine.energy.collect { _audioEnergy.value = it }
                }
                viewModelScope.launch {
                    s.audioEngine.decibels.collect { _audioDecibels.value = it }
                }
            }
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            virtualCameraService = null
            _isServiceBound.value = false
        }
    }

    init {
        viewModelScope.launch {
            repository.initDefaultDataIfNeeded()
        }
        loadInstalledApps()
    }

    private fun loadInstalledApps() {
        viewModelScope.launch(Dispatchers.IO) {
            val pm = getApplication<Application>().packageManager
            val intent = Intent(Intent.ACTION_MAIN, null).apply {
                addCategory(Intent.CATEGORY_LAUNCHER)
            }
            
            // Handle Android 11+ package visibility securely
            val resolveInfoList = try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    pm.queryIntentActivities(intent, PackageManager.ResolveInfoFlags.of(0L))
                } else {
                    @Suppress("DEPRECATION")
                    pm.queryIntentActivities(intent, 0)
                }
            } catch (e: Exception) {
                emptyList()
            }

            val apps = resolveInfoList.mapNotNull { resolveInfo ->
                try {
                    AppInfo(
                        packageName = resolveInfo.activityInfo.packageName,
                        appName = resolveInfo.loadLabel(pm).toString(),
                        icon = resolveInfo.loadIcon(pm),
                        isCloned = false
                    )
                } catch (e: Exception) {
                    null
                }
            }.distinctBy { it.packageName }.sortedBy { it.appName }

            _installedApps.value = apps
        }
    }

    fun cloneApp(app: AppInfo) {
        val currentCloned = _clonedApps.value.toMutableList()
        if (currentCloned.none { it.packageName == app.packageName }) {
            currentCloned.add(app.copy(isCloned = true))
            _clonedApps.value = currentCloned
            
            // Update installed list to reflect it's cloned
            _installedApps.value = _installedApps.value.map { 
                if (it.packageName == app.packageName) it.copy(isCloned = true) else it
            }
        }
    }

    fun removeClonedApp(app: AppInfo) {
        val currentCloned = _clonedApps.value.toMutableList()
        currentCloned.removeAll { it.packageName == app.packageName }
        _clonedApps.value = currentCloned

        _installedApps.value = _installedApps.value.map {
            if (it.packageName == app.packageName) it.copy(isCloned = false) else it
        }
    }

    fun launchClonedApp(app: AppInfo) {
        val context = getApplication<Application>()
        try {
            // First, ensure our Virtual Camera Service and Floating Bubble are running
            startService()
            val bubbleIntent = Intent(context, VirtualCameraService::class.java).apply {
                action = VirtualCameraService.ACTION_SHOW_OVERLAY
            }
            context.startService(bubbleIntent)
            
            // Then launch the specific app
            val launchIntent = context.packageManager.getLaunchIntentForPackage(app.packageName)
            if (launchIntent != null) {
                launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(launchIntent)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun startService(resultCode: Int? = null, resultData: Intent? = null) {
        val app = getApplication<Application>()
        val intent = Intent(app, VirtualCameraService::class.java).apply {
            action = VirtualCameraService.ACTION_START
            if (resultCode != null && resultData != null) {
                putExtra(VirtualCameraService.EXTRA_RESULT_CODE, resultCode)
                putExtra(VirtualCameraService.EXTRA_RESULT_DATA, resultData)
            }
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            app.startForegroundService(intent)
        } else {
            app.startService(intent)
        }

        app.bindService(intent, serviceConnection, Context.BIND_AUTO_CREATE)
        viewModelScope.launch {
            repository.updateSettings { it.copy(isVirtualCamActive = true) }
        }
    }

    fun stopService() {
        val app = getApplication<Application>()
        if (_isServiceBound.value) {
            try {
                app.unbindService(serviceConnection)
            } catch (e: Exception) {
                e.printStackTrace()
            }
            _isServiceBound.value = false
        }

        val intent = Intent(app, VirtualCameraService::class.java).apply {
            action = VirtualCameraService.ACTION_STOP
        }
        app.startService(intent)

        viewModelScope.launch {
            repository.updateSettings { it.copy(isVirtualCamActive = false) }
        }
    }

    fun togglePlayPause() {
        virtualCameraService?.togglePlayPause() ?: run {
            _isPlaying.value = !_isPlaying.value
        }
    }

    fun toggleMirror() {
        virtualCameraService?.toggleMirror() ?: run {
            viewModelScope.launch {
                val next = !settings.value.isMirrorHorizontal
                repository.updateSettings { it.copy(isMirrorHorizontal = next) }
            }
        }
    }

    fun toggleVirtualCam() {
        virtualCameraService?.toggleVirtualCam() ?: run {
            viewModelScope.launch {
                val next = !settings.value.isVirtualCamActive
                repository.updateSettings { it.copy(isVirtualCamActive = next) }
            }
        }
    }

    fun nextVideo() {
        virtualCameraService?.nextVideo() ?: run {
            val list = videos.value
            if (list.isNotEmpty()) {
                _currentVideoIndex.value = (_currentVideoIndex.value + 1) % list.size
            }
        }
    }

    fun prevVideo() {
        virtualCameraService?.previousVideo() ?: run {
            val list = videos.value
            if (list.isNotEmpty()) {
                val p = _currentVideoIndex.value - 1
                _currentVideoIndex.value = if (p < 0) list.size - 1 else p
            }
        }
    }

    fun selectVideo(index: Int) {
        virtualCameraService?.selectVideoIndex(index)
        _currentVideoIndex.value = index
    }

    fun importVideos(uris: List<Uri>) {
        val app = getApplication<Application>()
        viewModelScope.launch {
            uris.forEachIndexed { i, uri ->
                val title = "Imported Feed #${videos.value.size + i + 1}.mp4"
                repository.addVideo(
                    title = title,
                    uriString = uri.toString(),
                    durationMs = 30000L,
                    resolution = "1080x1920"
                )
            }
        }
    }

    fun deleteVideo(id: Long) {
        viewModelScope.launch {
            repository.removeVideo(id)
        }
    }

    fun updateLoopMode(mode: String) {
        viewModelScope.launch {
            repository.updateSettings { it.copy(loopMode = mode) }
        }
    }

    fun updateSpeed(speed: Float) {
        viewModelScope.launch {
            repository.updateSettings { it.copy(playbackSpeed = speed) }
        }
    }

    fun updateLipSync(enabled: Boolean) {
        virtualCameraService?.let {
            it.lipSyncEngine.isEnabled = enabled
        }
        viewModelScope.launch {
            repository.updateSettings { it.copy(lipSyncEnabled = enabled) }
        }
    }

    fun updateLipSyncSensitivity(sensitivity: Float) {
        virtualCameraService?.let {
            it.lipSyncEngine.sensitivity = sensitivity
        }
        viewModelScope.launch {
            repository.updateSettings { it.copy(lipSyncSensitivity = sensitivity) }
        }
    }

    fun updateNoiseCancellation(enabled: Boolean) {
        virtualCameraService?.let {
            it.audioEngine.isNoiseCancellationEnabled = enabled
        }
        viewModelScope.launch {
            repository.updateSettings { it.copy(noiseCancellationEnabled = enabled) }
        }
    }

    fun selectVoicePreset(preset: VoicePreset) {
        virtualCameraService?.let {
            it.audioEngine.currentVoicePreset = preset
        }
        viewModelScope.launch {
            repository.updateSettings { it.copy(voicePreset = preset.name) }
        }
    }

    override fun onCleared() {
        if (_isServiceBound.value) {
            try {
                getApplication<Application>().unbindService(serviceConnection)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
        super.onCleared()
    }
}
