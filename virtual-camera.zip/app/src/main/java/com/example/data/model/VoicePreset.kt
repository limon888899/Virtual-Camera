package com.example.data.model

enum class VoicePreset(
    val title: String,
    val description: String,
    val pitchShift: Float,
    val cutoffFreq: Int,
    val resonance: Float
) {
    NATURAL("Original Natural", "Pass-through audio with clear dynamics", 1.0f, 20000, 1.0f),
    STUDIO("Studio Broadcast", "Crisp studio EQ with vocal clarity booster", 1.05f, 16000, 1.2f),
    DEEP_VOCAL("Deep Voice Clone", "Sub-bass resonance and masculine tone", 0.75f, 8000, 1.5f),
    ROBOTIC("Cyber Robotic", "Synthesized vocoder frequency modulation", 1.2f, 4000, 2.0f),
    FEMALE_PITCH("High Vocal / Female", "Pitch shifted for feminine bright acoustics", 1.4f, 18000, 1.1f),
    MALE_PITCH("Low Vocal / Male", "Baritone resonant pitch shift", 0.82f, 10000, 1.3f);

    companion object {
        fun fromString(name: String): VoicePreset {
            return entries.firstOrNull { it.name.equals(name, ignoreCase = true) } ?: NATURAL
        }
    }
}
